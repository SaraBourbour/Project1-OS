#!/bin/bash

# alamode-execute.sh

./alamode-fetch.sh -f hosts.txt | ./alamode-publish.sh 