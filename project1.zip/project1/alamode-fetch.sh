#!/bin/bash

# alamode-fetch.sh

while getopts "n:d:f:" OPTIONS; do
	case "$OPTIONS" in
		f)  if [ ! -z $READ_FILE ]; then # Check if we've parsed this flag already
				echo "$0: does not support multiple -f's"
				exit 1
			elif [ ! -z $MACH]; then # Check if we've parsed the -n flag already
				echo "$0: requires a -n or -f flag, not both"
				exit 1
			elif [ ! -z $OPTARG ]; then # Check to make sure a token was given with this flag
				READ_FILE=$OPTARG
				#INPUT VALIDATION
				if [ ! -f $READ_FILE ]; then #Check if file exists
					echo "$0: The file \"$READ_FILE\" does not exist."
					exit 1
				fi
				if [ ! -r $READ_FILE ]; then #Check if we have read permissions
					echo "$0: Cannot read \"$READ_FILE\"; check permissions."
					exit 1
				fi
			else
				echo "$0: Must specify a file that contains the hostnames/IPs with -f"
				exit 1
			fi
		;;
		n)  if [ ! -z $READ_FILE ]; then # Check if we've parsed the -f flag already
				echo "$0: requires a -n or -f flag, not both"
				exit 1
			elif [ ! -z $MACH]; then # Check if we've parsed the -n flag already
				echo "$0: does not support multiple -n's"
				exit 1
			elif [ ! -z $OPTARG ]; then # Check to make sure a token was given with this flag
				MACH=$OPTARG
			else
				echo "$0: Must specify a hostname/IP with -n"
				exit 1
			fi
		;;
		d)  if [ ! -z $DIRE]; then # Check if we've parsed the -d flag already
				echo "$0: does not support multiple -d's"
				exit 1
			elif [ ! -z $OPTARG ]; then # Check to make sure a token was given with this flag
				DIRE=$OPTARG
				#INPUT VALIDATION
				if [ ! -d "$DIRE" ]; then
					mkdir $DIRE
				fi
				if [[ "${DIRE: -1}" != "/" ]]; then
					DIRE="$DIRE/"
				fi
			else
				echo "$0: Must specify a directory with -d"
				exit 1
			fi
		;;
		\?) echo "usage: $0 [-d directory (OPTIONAL)] [-n IP or Name of computer] or [-f File containing names or IPs]"
			exit 1
		;;
	esac
done

#CHECK THAT THERE IS AT LEAST ONE COMPUTER TO SSH TO (eg: -f or -n option was provided with an argument)
if [ "$READ_FILE" = "" ] && [ "$MACH" = "" ]; then
	echo "usage: $0 [-d directory (OPTIONAL)] [-n IP or Name of computer] or [-f File containing names or IPs]"
	exit 1
elif [ "$READ_FILE" = "" ]; then
	MACH_ARRAY=($MACH)
else
	OLD_IFS=$IFS #IFS Stuff affects how the array is formed
	IFS=$'\n'
	MACH_ARRAY=(`cat $READ_FILE`) #Form the array
	IFS=$OLD_IFS
fi

#CHECK THE OUTPUT DIRECTORY
if [ "$DIRE" = "" ]; then
	DIRE="`mktemp -d /tmp/alamodeFetch.XXXXXXXX`/"
fi

#CHECK THE INPUT HOST COMPUTERS
for CHECK in "${MACH_ARRAY[@]}"; do 
	ping $CHECK -c 1 > /dev/null 2> /dev/null
	
	#ENSURE THAT THE PING COMMAND WAS SUCCESSFUL
	if (("$?"!=0)); then
		echo "$0: invalid host: $CHECK"
		exit 1
	fi
done

#ASSEMBLE COMMANDS
#(1) how many users are currently logged in
COMMANDS="echo -n 'hostname:  '"
COMMANDS="$COMMANDS; hostname"
COMMANDS="$COMMANDS; echo -n '1) users logged in:  '"
COMMANDS="$COMMANDS; who | wc -l"
#(2) how many processes are currently executing in each possible state (i.e., running, sleeping, stopped, and zombie states)
COMMANDS="$COMMANDS; echo '2) executing processes:'"
COMMANDS="$COMMANDS; echo -n '    A) running processes:  '"
COMMANDS="$COMMANDS; ps aux | awk '{ print \$8 }' | grep '^R' | wc -l"
COMMANDS="$COMMANDS; echo -n '    B) sleeping processes (interruptible):  '"
COMMANDS="$COMMANDS; ps aux | awk '{ print \$8 }' | grep -v 'STAT' | grep '^S' | wc -l"
COMMANDS="$COMMANDS; echo -n '       sleeping processes (uninterruptible):  '"
COMMANDS="$COMMANDS; ps aux | awk '{ print \$8 }' | grep '^D' | wc -l"
COMMANDS="$COMMANDS; echo -n '    C) stopped processes:  '"
COMMANDS="$COMMANDS; ps aux | awk '{ print \$8 }' | grep '^T' | wc -l"
COMMANDS="$COMMANDS; echo -n '    D) zombie processes:  '"
COMMANDS="$COMMANDS; ps aux | awk '{ print \$8 }' | grep '^Z' | wc -l"
#(3) the average load for the last one, ﬁve and ﬁfteen minutes
COMMANDS="$COMMANDS; echo -n '3) average load:  '"
COMMANDS="$COMMANDS; uptime | sed 's/^.* load average: \(.*\)/\1/'"

#RUN THE SSH COMMAND
for COMPUTER in "${MACH_ARRAY[@]}"; do
	ssh "$COMPUTER" "$COMMANDS" > "$DIRE$COMPUTER"
done

echo "$DIRE"
