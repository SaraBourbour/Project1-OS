#!/bin/bash

# alamode-publish.sh

while getopts "s:d:" OPTIONS; do
	case "$OPTIONS" in
		s)  if [ ! -z $IN_DIR ]; then # Check if we've parsed this flag already
				echo "$0: does not support multiple -s's"
				exit 1
			elif [ ! -z $OPTARG ]; then # Make sure a token was given with this flag
				IN_DIR=$OPTARG
			else
				echo "$0: Must specify a directory that contains the hostname/IP results with -s"
				exit 1
			fi
		;;
		d)  if [ ! -z $OUT_DIR ]; then # Check if we've parsed this flag already
				echo "$0: does not support multiple -d's"
				exit 1
			elif [ ! -z $OPTARG ]; then # Make sure a token was given with this flag
				OUT_DIR=$OPTARG
				#INPUT VALIDATION
				if [ ! -d "$OUT_DIR" ]; then
					mkdir $OUT_DIR
				fi
				if [[ "${OUT_DIR: -1}" != "/" ]]; then
					OUT_DIR="$OUT_DIR/"
				fi
			else
				echo "$0: Must specify a directory for the HTML results with -d"
				exit 1
			fi
		;;
		\?) echo "usage: $0 [[source directory] OR [-s source directory]] [-d destination directory]"
			exit 1
		;;
	esac
done

if [ -z $IN_DIR ]; then
	read IN_DIR
fi
#INPUT DIRECTORY VALIDATION
if [ ! -d "$IN_DIR" ]; then
	echo "$0: input directory '$IN_DIR' is not a valid directory"
	exit 1
fi
if [[ "${IN_DIR: -1}" != "/" ]]; then
	IN_DIR="$IN_DIR/"
fi

#OUTPUT DIRECTORY
if [ -z $OUT_DIR ]; then
	OUT_DIR='./'
fi

#GATHER THE INPUT FILES FOR EACH MACHINE
data_files=(`ls $IN_DIR`)

#SETUP HTML FILE
HTML_FILE='alamode-HTML.html'

#Setup the HTML file header:
echo -n "<HTML><HEAD><title>ALAMODE Machine Use</title></head><body><center>" > "$OUT_DIR$HTML_FILE"
if [ ${#data_files[@]} = 0 ]; then
	echo -n "<p>No Machine Data to Display!</p>" >> "$OUT_DIR$HTML_FILE"
else
	echo -n "<p><h1>Machine Data</h1>(color coded based on the average load over 5 minutes)</p><table border="3" cellpadding="2" cellspacing="0"><tr><th>Machine</th><th># Users</th><th>Running Processes</th><th>Interruptable Sleeping Processes</th><th>Un-interruptable Sleeping Processes</th><th>Stopped Processes</th><th>Zombie Processes</th><th>Average Load<br>(1 min)</th><th>Average Load<br>(5 min)</th><th>Average Load<br>(15 min)</th></tr>" >> "$OUT_DIR$HTML_FILE"
	#parse & output information from each data file.
	for data_file in "${data_files[@]}"; do
		#parse & output information from each data file.
		host=`cat $IN_DIR$data_file | grep "hostname" | sed 's/.*hostname: *\(.*\)/\1/'`
		users=`cat $IN_DIR$data_file | grep "1) users" | sed 's/.*users logged in: *\(.*\)/\1/'`
		r_pro=`cat $IN_DIR$data_file | grep "A) running" | sed 's/.*running processes: *\(.*\)/\1/'`
		i_sl_pro=`cat $IN_DIR$data_file | grep "B) sleeping" | sed 's/.*(interruptible): *\(.*\)/\1/'`
		u_sl_pro=`cat $IN_DIR$data_file | grep "(uninterruptible):" | sed 's/.*(uninterruptible): *\(.*\)/\1/'`
		st_pro=`cat $IN_DIR$data_file | grep "C) stopped" | sed 's/.*stopped processes: *\(.*\)/\1/'`
		z_pro=`cat $IN_DIR$data_file | grep "D) zombie" | sed 's/.*zombie processes: *\(.*\)/\1/'`
		av1=`cat $IN_DIR$data_file | grep "3) average" | sed 's/.*average load: *\([0-9\.]*\), *[0-9\.]*, *[0-9\.]*.*/\1/'`
		av5=`cat $IN_DIR$data_file | grep "3) average" | sed 's/.*average load: *[0-9\.]*, *\([0-9\.]*\), *[0-9\.]*.*/\1/'`
		av15=`cat $IN_DIR$data_file | grep "3) average" | sed 's/.*average load: *[0-9\.]*, *[0-9\.]*, *\([0-9\.]*\).*/\1/'`
		if [ -z $av5 ]; then
			color="444444" #Gray - this should not occur, unless an extraneous file is located in the directory that contains the host files.
		elif (( $(echo "$av5 > .7" | bc -l) )); then
			color="FF0000" #Red
		elif (( $(echo "$av5 < .3" | bc -l) )); then
			color="00FF00" #Green
		else
			color="FFFF00" #Yellow
		fi
		echo -n "<tr bgcolor="$color"><td>$host</td><td>$users</td><td>$r_pro</td><td>$i_sl_pro</td><td>$u_sl_pro</td><td>$st_pro</td><td>$z_pro</td><td>$av1</td><td>$av5</td><td>$av15</td></tr>" >> "$OUT_DIR$HTML_FILE"
	done	
	echo -n "</table>" >> "$OUT_DIR$HTML_FILE"
fi

echo "</center></body></html>" >> "$OUT_DIR$HTML_FILE"

echo "$OUT_DIR$HTML_FILE"
